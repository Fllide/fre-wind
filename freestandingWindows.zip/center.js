var Windows = []; 

for (i=0; i<2; i++)
{
 Windows.push( new Window('Window'+i, i))
} 

